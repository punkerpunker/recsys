from setuptools import setup, find_packages

setup(
    name='RecSys',
    packages=find_packages(),
    description='Recommender system extensions',
    version='0.1.0',
    url='https://github.com/punkerpunker/recsys',
    author='Punker',
    author_email='gleb.vazhenin@pwc.com'
    )

